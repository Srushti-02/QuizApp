package com.example.demo;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class QuizService {
	@Autowired
	private QuestionRepository questionRepository;
	@Autowired
	private QuizSessionRepository quizSessionRepository;
	
	public QuizSession startNewSession() {
		QuizSession session = new QuizSession();
		session.setTotalQuestionsAnswered(0);
		session.setCorrectAnswers(0);
		session.setIncorrectAnswers(0);
		return quizSessionRepository.save(session);
	}
	
	public Question getRandomQuestion() {
		List<Question> questions = questionRepository.findAll();
		Random random = new Random();
		return questions.get(random.nextInt(questions.size()));
	}
	
	public QuizSession submitAnswer(Long sessionId, Long questionId, String userAnswer) {
		Optional<QuizSession> sessionOptional = quizSessionRepository.findById(sessionId);
		if (sessionOptional.isEmpty()) {
            throw new RuntimeException("Quiz session not found");
        }
        QuizSession session = sessionOptional.get();
        Optional<Question> questionOptional = questionRepository.findById(questionId);
        if (questionOptional.isEmpty()) {
            throw new RuntimeException("Question not found");
        }
        Question question = questionOptional.get();
        session.setTotalQuestionsAnswered(session.getTotalQuestionsAnswered() + 1);
        if (question.getCorrectAnswer().equalsIgnoreCase(userAnswer)) {
            session.setCorrectAnswers(session.getCorrectAnswers() + 1);
        } else {
            session.setIncorrectAnswers(session.getIncorrectAnswers() + 1);
        }
        return quizSessionRepository.save(session);
	}
}
