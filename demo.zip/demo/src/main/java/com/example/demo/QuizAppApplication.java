package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class QuizAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuizAppApplication.class, args);
    }

    @Bean
    public CommandLineRunner seedDatabase(QuestionRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                Question q1 = new Question();
                q1.setQuestion("What is the capital of France?");
                q1.setOptionA("Berlin");
                q1.setOptionB("Madrid");
                q1.setOptionC("Paris");
                q1.setOptionD("Rome");
                q1.setCorrectAnswer("Paris");

                Question q2 = new Question();
                q2.setQuestion("What is 2 + 2?");
                q2.setOptionA("3");
                q2.setOptionB("4");
                q2.setOptionC("5");
                q2.setOptionD("6");
                q2.setCorrectAnswer("4");

                repository.save(q1);
                repository.save(q2);

                System.out.println("Database seeded with sample questions.");
            }
        };
    }
}

