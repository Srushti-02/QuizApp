INSERT INTO QUESTION (QUESTION, OPTION_A, OPTION_B, OPTION_C, OPTION_D, CORRECT_ANSWER)
VALUES
('What is the capital of France?', 'Berlin', 'Madrid', 'Paris', 'Rome', 'Paris'),
('What is 2 + 2?', '3', '4', '5', '6', '4'),
('Which programming language is used for Android development?', 'Python', 'Kotlin', 'Java', 'C#', 'Kotlin');

INSERT INTO QUIZ_SESSION (TOTAL_QUESTIONS_ANSWERED, CORRECT_ANSWERS, INCORRECT_ANSWERS)
VALUES (0, 0, 0);
